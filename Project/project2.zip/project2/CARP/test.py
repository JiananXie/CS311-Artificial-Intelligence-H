a = [1,2,3,4]
a.insert(2,5)
print(a)